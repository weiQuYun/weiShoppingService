package com.wqy.wx.back.plus2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wqy.wx.back.plus2.entity.TRole;

/**
 * <p>
 * 角色权限 Mapper 接口
 * </p>
 *
 * @author licm
 * @since 2020-04-03
 */
public interface TRoleMapper extends BaseMapper<TRole> {

}
